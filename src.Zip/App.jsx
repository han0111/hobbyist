import React from "react";
import Detail from "./pages/detail";

export default function App() {
  return (
    <>
      <Detail />
    </>
  );
}
